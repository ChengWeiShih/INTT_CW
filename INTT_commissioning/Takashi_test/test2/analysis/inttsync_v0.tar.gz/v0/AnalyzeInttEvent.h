#ifndef __ANALYZEINTTEVENT_H__
#define __ANALYZEINTTEVENT_H__


int InitAnalysis (const char* outRootfile); //++CINT 
int RunAnalysis (const char* rootFileList); //++CINT 

#endif /* __ANALYZEINTTEVENT_H__ */
