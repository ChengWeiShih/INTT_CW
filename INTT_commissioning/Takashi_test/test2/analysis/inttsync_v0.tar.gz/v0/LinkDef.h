#ifdef __CINT__
//#pragma link C++ defined_in "InttEvent.h";
#pragma link C++ function InitAnalysis;
#pragma link C++ function RunAnalysis;
#pragma link C++ class    InttHit+;
#pragma link C++ class    InttEvent+;
#pragma link C++ class    InttCluster;
#pragma link C++ class    InttClusterList;

#endif /* __CINT__ */
