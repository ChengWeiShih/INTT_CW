#ifdef __CINT__
//#pragma link C++ defined_in "InttEvent.h";
#pragma link C++ class InttHit+;
#pragma link C++ class InttEvent+;
#pragma link C++ function Init;
#pragma link C++ function Run;

#endif /* __CINT__ */
